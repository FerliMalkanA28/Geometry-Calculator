package com.example.kelompoktam;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;


public class Persegi_L extends AppCompatActivity {
    private Spinner spinner1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi_l);
        spinner1 = (Spinner) findViewById(R.id.spinner);

        spinner1.setOnItemSelectedListener(new Persegi_L.ItemSelectedListener());

        EditText bilangan = findViewById(R.id.bilangan);
        Button btnhasil = findViewById(R.id.btnhasil);
        TextView nilai = findViewById(R.id.tvNilai);
        btnhasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bilangan.getText().length() > 0) {
                    double angka1 = Double.parseDouble(bilangan.getText().toString());

                    double result = angka1 * angka1 ;
                    nilai.setText(Double.toString(result));
                } else {
                    Toast toast = Toast.makeText(Persegi_L.this, "Mohon masukan angka pertama & kedua", Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });
    }
    public class ItemSelectedListener implements AdapterView.OnItemSelectedListener {



        //get strings of first item

        String firstItem = String.valueOf(spinner1.getSelectedItem());

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

            if (firstItem.equals(String.valueOf(spinner1.getSelectedItem()))) {

            } else {

                Intent intent = new Intent(Persegi_L.this, Persegi_K.class);
                startActivity(intent);

                Toast.makeText(parent.getContext(),

                        "Anda telah memilih : " + parent.getItemAtPosition(pos).toString(),

                        Toast.LENGTH_LONG).show();

            }

        }
        @Override

        public void onNothingSelected(AdapterView<?> arg) {



        }

    }
}