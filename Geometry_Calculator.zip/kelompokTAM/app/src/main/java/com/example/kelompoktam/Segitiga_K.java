package com.example.kelompoktam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;


public class Segitiga_K extends AppCompatActivity {

    private Spinner spinner2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga_k);

        spinner2 = (Spinner) findViewById(R.id.spinner);
        spinner2.setOnItemSelectedListener(new ItemSelectedListener());

        EditText bilangan1 = findViewById(R.id.bilangan1);

        Button btnhasil = findViewById(R.id.btnhasil);
        TextView nilai = findViewById(R.id.tvNilai);
        btnhasil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bilangan1.getText().length() > 0)  {

                    double angka1 = Double.parseDouble(bilangan1.getText().toString());

                    double result = angka1 * angka1 * angka1 ;
                    nilai.setText(Double.toString(result));
                } else {
                    Toast toast = Toast.makeText(Segitiga_K.this, "Mohon masukan angka pertama & kedua", Toast.LENGTH_LONG);
                    toast.show();
                }
            }
        });


    }
    public class ItemSelectedListener implements AdapterView.OnItemSelectedListener {



        //get strings of first item

        String firstItem = String.valueOf(spinner2.getSelectedItem());

        public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

            if (firstItem.equals(String.valueOf(spinner2.getSelectedItem()))) {

            } else {

                Intent intent = new Intent(Segitiga_K.this, Segitiga_L.class);
                startActivity(intent);

                Toast.makeText(parent.getContext(),

                        "Anda telah memilih : " + parent.getItemAtPosition(pos).toString(),

                        Toast.LENGTH_LONG).show();

            }

        }
        @Override

        public void onNothingSelected(AdapterView<?> arg) {



        }

    }
}