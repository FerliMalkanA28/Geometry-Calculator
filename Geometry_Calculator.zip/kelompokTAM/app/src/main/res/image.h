//
// Created by Reyond on 5/5/2023.
//

#ifndef KELOMPOKTAM_IMAGE_H
#define KELOMPOKTAM_IMAGE_H



class image {

};



#endif //KELOMPOKTAM_IMAGE_H
