package com.example.kelompoktam;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void persegi(View view){
        Intent intent = new Intent(MainActivity.this, Persegi_K.class);
        startActivity(intent);
    }

    public void kalkulator(View view){
        Intent intent = new Intent(MainActivity.this, Segitiga_L.class);
        startActivity(intent);
    }
    public void trapesium(View view){
        Intent intent = new Intent(MainActivity.this, Trapesium_K.class);
        startActivity(intent);
    }
}